<div class="footer-sub">
    <div class="row">
        <div class="col-sm-12">
            <div class="footer-submenu">
                <a href="">
                    <i class="fas fa-arrow-left"></i> <!-- Replaces back.png with a hamburger menu icon -->
                </a>
                <a href="">
                    <i class="fas fa-user"></i> <!-- Replaces user.png with a user icon -->
                </a>
                <a href="">
                    <i class="fas fa-bars"></i> <!-- Replaces back.png with a hamburger menu icon -->
                </a>
            </div>

        </div>
    </div>
</div>

</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js"></script>
<script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-toast-plugin/1.3.2/jquery.toast.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@fancyapps/ui@5.0.0/dist/fancybox/fancybox.umd.js"></script>
<!-- <script src="{{asset('backend/js/custom.js')}}"></script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.5.7/jquery.fancybox.min.js"></script>
<script src="{{asset('backend/js/custom.js')}}"></script>
<!-- Include Cropper.js JS -->
<script src="https://unpkg.com/cropperjs/dist/cropper.js"></script>
</body>

</html>