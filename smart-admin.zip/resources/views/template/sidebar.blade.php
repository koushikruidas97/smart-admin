<div class="col-sm-3 sidebar-bg">
    <div class="sidebar-main">
        <div class="account-sec">
            <div class="account-icon">
                <img src="{{ asset('backend/images/profile.png') }}" alt="">
            </div>
            <div class="account-text">
                <span>Koushik Ruidas</span>
                <small>ID : AB3025</small>
            </div>
        </div>
        <div class="sidebar-menu">
            <ul>
                @php
                $pageform = Request::segment(1); // Get the first segment of the URL
                @endphp
                <li class="{{ $pageform === 'dashboard' ? 'active' : '' }}">
                    <a href="javascript:void(0)" onclick="window.location='/dashboard'">
                        <i class="fas fa-tachometer-alt"></i>
                        Dashboard
                    </a>
                </li>
                <li class="{{ $pageform === 'banners' ? 'active' : '' }}">
                    <a href="javascript:void(0)" onclick="window.location='/banners'">
                        <i class="fas fa-images"></i>
                        Banner
                    </a>
                </li>
                <li class="{{ $pageform === 'gallery' ? 'active' : '' }}">
                    <a href="javascript:void(0)" onclick="window.location='/gallery'">
                        <i class="fas fa-images"></i>
                        Gallery
                    </a>
                </li>
                <li class="{{ $pageform === 'service-category' ? 'active' : '' }}">
                    <a href="javascript:void(0)" onclick="window.location='/service-category'">
                        <i class="fas fa-th-large"></i>
                        Service Category
                    </a>
                </li>
                <li class="{{ $pageform === 'service' ? 'active' : '' }}">
                    <a href="javascript:void(0)" onclick="window.location='/service'">
                        <i class="fas fa-concierge-bell"></i>
                        Services
                    </a>
                </li>
                <li class="{{ $pageform === 'pincode' ? 'active' : '' }}">
                    <a href="javascript:void(0)" onclick="window.location='/pincode'">
                        <i class="fas fa-location"></i>
                        Pincode List
                    </a>
                </li>
                <li class="{{ $pageform === 'testimonials' ? 'active' : '' }}">
                    <a href="javascript:void(0)" onclick="window.location='/testimonials'">
                        <i class="fas fa-users"></i>
                        Testimonials
                    </a>
                </li>
                <li class="{{ $pageform === 'booking-list' ? 'active' : '' }}">
                    <a href="javascript:void(0)" onclick="window.location='/booking-list'">
                        <i class="fas fa-calendar-check"></i>
                        Booking
                    </a>
                </li>
                <li class="{{ $pageform === 'contact-req' ? 'active' : '' }}">
                    <a href="javascript:void(0)" onclick="window.location='/contact-req'">
                        <i class="fas fa-users"></i>
                        Contact Request
                    </a>
                </li>
            </ul>

        </div>
    </div>
</div>