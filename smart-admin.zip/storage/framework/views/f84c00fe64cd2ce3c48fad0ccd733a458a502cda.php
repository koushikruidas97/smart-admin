<?php echo $__env->make('template.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php
// Dynamically populate form fields using the passed $menuData
$formFields = [
    [
        'id' => 'menuName',
        'label' => 'Menu Name',
        'name' => 'menu_id',
        'type' => 'dropdown',
        'options' => []
    ],
    [
        'id' => 'title',
        'label' => 'Title',
        'name' => 'title',
        'type' => 'text'
    ],
    [
        'id' => 'description',
        'label' => 'Description',
        'name' => 'description',
        'type' => 'textarea'
    ],
    [
        'id' => 'image',
        'label' => 'Image',
        'name' => 'image',
        'type' => 'file'
    ]
];

foreach ($menuData as $menu) {
    $formFields[0]['options'][] = [
        'value' => $menu->id, // Assuming 'id' is the menu's unique identifier
        'label' => $menu->name // Assuming 'name' is the display name of the menu
    ];
}
?>

<?php
$pageform = Request::segment(1); // Get the first segment of the URL
?>

<!-- main-wrap -->
<div class="container-fluid">
    <div class="row">
        <?php echo $__env->make('template.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="col-sm-9">
            <div class="ban">
                <div class="left-ban">
                    <div class="left-ban-text">
                        <p><i class="fas fa-images"></i> <?php echo e(ucfirst($pageform)); ?></p>
                    </div>
                </div>
                <div class="right-ban">
                    <div class="right-ban-text">
                        <p>
                            <span class="parent-page" onclick="window.location.href='/dashboard'">Dashboard</span>
                            <span class="slash">/</span>
                            <span><?php echo e(ucfirst($pageform)); ?></span>
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-sm-12 mt-5 text-end">
                <a href="javascript:void(0)" class="btn btn-primary" onclick="menu(null,'<?= base64_encode(json_encode($formFields)) ?>',null,'<?php echo e($pageform); ?>')">
                    <i class="fas fa-solid fa-circle-plus"></i> Add Banner
                </a>
            </div>
            <div class="col-sm-12 mt-3">
                <div class="card br-primary">
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Menu Name</th>
                                    <th>Title</th>
                                    <th>Description</th>
                                    <th>Image</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr id="row-<?php echo e($item->id); ?>">
                                    <td>
                                        <?php $__currentLoopData = $menuData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($item->menu_id == $menu->id): ?>
                                        <?php echo e(Str::limit($menu->name,20)); ?>

                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                    <td><?php echo e(Str::limit($item->title,20)); ?></td>
                                    <td><?php echo e(Str::limit($item->description,20)); ?></td>
                                    <td>
                                        <?php if($item->image): ?>
                                        <a href="<?php echo e(asset('storage/'.$item->image)); ?>" data-fancybox="gallery" class="image-link">
                                            <img src="<?php echo e(asset('storage/'.$item->image)); ?>" class="w-10" alt="Image">
                                        </a>
                                        <?php endif; ?>
                                    </td>
                                    <td class="action-td">
                                        <div class="d-flex g-3">
                                            <a href="javascript:void(0)" onclick="menu('<?php echo e(base64_encode(json_encode($item))); ?>', '<?php echo e(base64_encode(json_encode($formFields))); ?>',null,'<?php echo e($pageform); ?>')" class="eact btn btn-primary">
                                                <i class="fa-solid fa-pen"></i>
                                            </a>
                                            <a href="javascript:void(0)" class="eact btn btn-danger" onclick="deleteModal('<?php echo e($item->id); ?>','<?php echo e($pageform); ?>')">
                                                <i class="fa-solid fa-trash"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <!-- Pagination Links -->
                <div class="d-flex justify-content-end mt-3" id="pagination">
                    <?php echo e($items->links('pagination::bootstrap-4')); ?>

                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('template.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script>
        $(document).ready(function() {
            $('[data-fancybox="gallery"]').fancybox({
                // Optional customization
                buttons: [
                    "zoom",
                    "close"
                ],
                // Add other settings if necessary
            });
        });
    </script><?php /**PATH C:\xampp\htdocs\admin-panel\resources\views/banners.blade.php ENDPATH**/ ?>